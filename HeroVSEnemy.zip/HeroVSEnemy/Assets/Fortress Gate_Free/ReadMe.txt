"Fortress Gate" is the free version of "Fortress Pack".
The model can be used on Mobil or any other platform, it contains a Low Poly version of the structures.
It also has Hand painted High Quality textures.
With "Fortress Pack" you can create several different designs from the walls, main structure and several towers, that can stand on the ground or be attached to larger structures, as sown on the Screenshots.
It uses only one Texture, a 1024x1024 TGA

Thank you, and may it serve you well!